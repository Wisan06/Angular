export const appsettings = {
    apiUrl: "http://localhost:5244/api/"
}