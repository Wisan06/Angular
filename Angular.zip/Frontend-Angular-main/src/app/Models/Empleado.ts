export interface Empleado {
    idEmpleado : number;
    nombreCompleto : string;
    correo : string;
    sueldo : number;
    fechaContrato : string;
}