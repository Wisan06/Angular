export interface ResponseAPI{
    isSuccess:boolean;
}